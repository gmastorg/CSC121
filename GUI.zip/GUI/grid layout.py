# Lay out components in a grid
#import the tkinter module
import tkinter as tk

# how to import the ttk module from the tkinter module
from tkinter import ttk

##How to create an empty root window
root = tk.Tk()
root.title("Future Value Calculator")
root.geometry("300x200")


# how to create a frame and add it to the root window
frame = ttk.Frame(root, padding="10 10 10 10")
frame.pack(fill=tk.BOTH, expand=True)

# How to use a grad it lay out compoents in a frame

ttk.Label(frame, text="Monthly Investment").grid(column=0, row=0, sticky=tk.E)
investmentText = tk.StringVar()
ttk.Entry(frame, width=25, textvariable=investmentText).grid(column=1, row=0)
ttk.Label(frame, text="Yearly Interest Rate").grid(column=0, row=1, sticky=tk.E)
rateText = tk.StringVar()
ttk.Entry(frame, width=25, textvariable=rateText).grid(column=1, row=1)

## How to make the root window visible
root.mainloop()



