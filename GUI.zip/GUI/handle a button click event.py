# Handle a button click event
#import the tkinter module
import tkinter as tk

# how to import the ttk module from the tkinter module
from tkinter import ttk

# the callback functions that the buttons are connected to
def click_button1():
    root.title("You clicked the button!")
def click_button2():
    root.destroy()
    
##How to create an empty root window
root = tk.Tk()
root.title("Future Value Calculator")
root.geometry("300x200")


# how to create a frame and add it to the root window
frame = ttk.Frame(root, padding="10 10 10 10")
frame.pack(fill=tk.BOTH, expand=True)


    
# How to create two buttons and add them to the frame
button1 = ttk.Button(frame, text="Click Me!", command=click_button1)
button2 = ttk.Button(frame, text="No, Click Me!", command=click_button2)


button1.pack()
button2.pack()


## How to make the root window visible
root.mainloop()



