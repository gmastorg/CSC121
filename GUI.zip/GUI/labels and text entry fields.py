# Handle a labels and text entry
#import the tkinter module
import tkinter as tk

# how to import the ttk module from the tkinter module
from tkinter import ttk

##How to create an empty root window
root = tk.Tk()
root.title("Future Value Calculator")
root.geometry("300x200")


# how to create a frame and add it to the root window
frame = ttk.Frame(root, padding="10 10 10 10")
frame.pack(fill=tk.BOTH, expand=True)

#Create a lable and display it
investmentLabel = ttk.Label(frame, text="Monthly Investment")
investmentLabel.pack()

#Another way to create and display a label
#ttk.Label(frame,text="Monthly Investment").pack()

#How to create a text entry field and bind it to the StringVar object
investmentText = tk.StringVar()
investmentEntry = ttk.Entry(frame, width=25, textvariable=investmentText)
investmentEntry.pack()

# Create a Label and display it
ttk.Label(frame,text="Future Value").pack()

#How to create a read only text entry field and bind it to a StringVar object

fvText = tk.StringVar()
fvEntry = ttk.Entry(frame, width=25, textvariable=fvText, state="readonly")
fvEntry.pack()

# How to get or set a string in a text entry field

investment = investmentText.get()
fvText.set("$2,000")

## How to make the root window visible
root.mainloop()



