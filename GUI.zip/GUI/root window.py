#import the tkinter module
import tkinter as tk

#How to create an empty root window
root = tk.Tk()
root.title("Future Value Calculator")
root.geometry("300x200")

# How to make the root window visible
root.mainloop()
